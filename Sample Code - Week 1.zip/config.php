<?php
// This is an example of config.php
$dbhost = 'us-cdbr-azure-southcentral-f.cloudapp.net';
$dbuser = 'bbece113092b36';
$dbpass = 'd9e55a1e';
$dbname = 'db-83e13e57-9556';
?>
